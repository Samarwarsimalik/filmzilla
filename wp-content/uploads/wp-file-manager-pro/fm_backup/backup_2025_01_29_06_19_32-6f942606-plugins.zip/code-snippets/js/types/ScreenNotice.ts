export type ScreenNotice = ['error' | 'updated', string]
