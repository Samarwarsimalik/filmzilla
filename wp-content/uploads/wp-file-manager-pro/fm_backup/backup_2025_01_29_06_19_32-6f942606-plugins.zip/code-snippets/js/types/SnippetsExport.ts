import type { Snippet } from './Snippet'

export interface SnippetsExport {
	generator: string
	date_created: string
	snippets: Snippet[]
}
