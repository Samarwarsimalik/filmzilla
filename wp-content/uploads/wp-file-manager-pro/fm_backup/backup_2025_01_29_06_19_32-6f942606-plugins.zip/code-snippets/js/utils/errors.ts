export const handleUnknownError = (error: unknown) => {
	console.error(error)
}
