import { handleEditorPreviewUpdates, handleSettingsTabs } from './services/settings'

handleSettingsTabs()
handleEditorPreviewUpdates()
